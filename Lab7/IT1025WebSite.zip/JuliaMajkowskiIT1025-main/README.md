# JuliaMajkowskiIT1025
IT 1025 is the first course for the Progrmming and Development program as well as most other IT related programs and all IT certificates. It will introduce you to computer, networking and programming concepts. This repository contains all labs required for the course to demonstarte the knowledge I will have gained by the end of it. 
