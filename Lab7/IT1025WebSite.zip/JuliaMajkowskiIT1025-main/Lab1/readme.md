# Executive Summary
The purpose of Lab 1 is to familiarize yourself with the way the IT 1025 course will be run, the beginnings of information systems, and gain experience using GitHub. You will also become familiar with the use of "markdown" language. The readings will give you some history on information systems, such as the creation of the PC and the World Wide Web.
## Information Systems Components
1. Hardware

   The hardware aspect is the tangible part of the system such as the keyboard.
2. Software

   The software aspect is the set of instructions that tells the hardware what it needs to do such as the operating system e.g. Mircosoft Windows.
3. Data

   The data aspect is a collection of information such as the day, date and time. It is not very useful when the information is unrelated but becomes a powerful tool when related.
4. People

   The people aspect is the variety of roles involved with informations systems, such as user support staff, which separate it from more technical fields like computer science. 
 5. Process
 
    The final aspect is the process which brigns together all of the other aspects. It is a series of steps taken to achieve a desired goal and bring more productivity. One example of this is Walmart's use of Retail Link, their supply chain mamangement system. It allowed their suppliers to directly see the store inventory to see how things were selling and request that the store carry more or less inventory for their products which allowed the stores to lower prices and run more effeciently. 
## Github
### Client-Server Architecture 
Client-server architecture is the connecting of computers to collaborate and share resources with other people. GitHub fits this model because it allows you to create code which can then be shared with others who can sugget additions or corrections to solve a problem that may have been found or even to create something new.
### Cloud Computing
Cloud computing gives people mobile access to data and appliations. An example of this is Dropbox which allows you to upload files for sharing that can be accessed from any device via the internet once uploaded.
# Conclusion
After completing Lab 1 I gained an overview for the expectations of the IT 1025 course, some background on the creation of information systems, and some experience using GitHub. I had an issue figuring out the formatting for the "markdown" language at first. After reviewing the examples and using the preview changes tab to see what the formatting looked like as I entered information, I was able to understand it. I believe the lab provided me with a better understanding of what to expect moving forward and I am excited to keep learning more. 
