# Executive Summary
The purpose of this lab is to review and gain a deeper understanding of Operating systems, Python IDLE, and graphics. First, using the command prompt to make a directory and then viewing the directory using the operating system's explorer application is done. Then, a continued study of Python using an Integrated Development and Learning Environment or IDLE will be accomplished. Finally, graphic rendering will be explored, specifically compression and design. A vector graphic will be created during this final section as well.

## Python IDLE
When first learning Python, using the IDLE is a helpful tool. The IDLE has an interacive shell that lets you execute commands one at a time and see the results instantly. However, when writing a full program in Python you need to use the file editor. The file editor looks similar to the Notepad on any compuer but it has features specific to coding. The main difference is that it lets you enter many intrustions at once and then is ran as a program instead of as one instruction at a time like with the shell.
### Code Examples
A variable is a space in the computer's memory where you can store a single value. For example spam can be used as a variable. In the reading, the author uses spam, bacon, and eggs as variable because in much of Pythin's documentation they are used because they aare inspired by the Monty Python "spam" sketch.

An assignment statement consists of a variable, equal sign, and a value. For example, spam=42 is an assignment statement that assigns spam the value of 42.

A function evaluatess the information entered into it accordingly. For example the len() function takes a string and evaluates it into an integer of the number of characters in the string.

There are three data types in Python. One is integers,1 2 3 etc., one is floating-point numbers, 1.0 2.0 0.5 etc, and one is strings,'a' 'ab' 'hello'.
## Graphics
### Raster vs. Vector
Raster images use tiny pixels to make up a larger image. They are not noticeable unless you zoom in or enlarge the image. Vector images are created using a special form of geometry so they do not lose quality when changing size.
### Lossless vs. Lossy Compression
Losless compression preserves all of the data from the original image file which results in larger file sizes. Lossy compression removes some data from the original file and saves the image with a reduced file size. 
### File Types
There are three main file types used in web images, JPEG,  PNG, and GIF. JPEG and PNG both are motionless images. However JPEG is better for low contrast images and simple images. PNG is better for high contrast images, images that require transparency, and more complex illustrations. GIF stands more alone as it is a animated image. It is best for line drawings and simple graphics or images that need animation.
### File Properties
The image desing I created is a pair of shears and a comb in a piece of hair with my Instagram handle to use as a logo for my pages. It took 4 layers, one for each image piece and one for the text with the handle name. The file size is 75.7 KB. It opens the file in the internet browser that is installed on the computer because it was created on a design website so there are not any other programs installed for it to open on currently. 

# Conclusion
The purpose of this lab was to review and gain a deeper understanding of Operating systems, Python IDLE, and graphics. Overall, the entire lab was intersting but the Python information was particularly useful. It took a while to figure out how to use the graphic desing website to create the logo but once it was figured out, it was fun to create a logo for personal use in the future. There were many things from the lab that will be put into use in the future.
