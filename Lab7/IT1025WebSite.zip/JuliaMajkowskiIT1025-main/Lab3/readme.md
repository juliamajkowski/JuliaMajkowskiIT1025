# Exeutive Summary
The purpose of this lab is to explore the software aspect of computing further. How operating systems, application and utility are used within software will be explained. Then the use of virtualization will be visited. Python will be read about an then used to gain some experience and understanding of how it works and why you would use it. Finally, careers in computing will be looked into as well as certificates, the co-op program and student and professional clubs/organizations.

## Software
There are various aspects to the software part of a computing system. The operation system, such as windows or mac, manages all of the hardware, provides user interface components, and provides a place for application writing. The second part of a software system is the application. This is for specific functions such as word processing or internet browsing via microsoft word or google chrome for example. The final aspect is the utility aspect, this allows you to modify your system in some way such as anti-malware systems like Norton. 

With the development of the internet and operating systems, the centralized control of company information shifted to become more cloud based. As time progressed the need for companies to have centralized control again became more apparent. The entrprise resource planning system , or ERP, was created to allow companies to have a localized network. Systems like Oracle allow for database management within an individual company. 

## Virtualization
Virtualization allows you to use more of a servers capacity by splitting one server into two or more unique idividual servers that can handle different tasks. This allows you to use hardware more efficiently to reduce cooling and maintenence costs. The hypervisor separate the physical resources needed for a specific thing from the virtual aspects.It splits up the physical resources so that the virtual enivronmnts can run them. When the virtual environemtn issues instructions that require phsyical information the hypervisor sends the request and caches the changes.

Virtualization and cloud computing are often confused. Virtualization is a technology while cloud computing is a methodology. Virtualization is used to deliver specific resources to specific places whereas cloud computing is used to deliver varying information to multiple places. A network administrator could move from virtualization to cloud computing by pooling, orchestrating and then creating a portal for for users to access the information or a program can be used to do some of that work for you. 

## Python
Python is a programming language that is simple and powerful. It has a pseudo-code nature, meaning it is meant for human reading and not machine reading. Python is an interprated language. This means it is run from the source code and doesn't require a software to copy the program to the hard disk and then run it. Complied programs like C++ have to be converted into binary and need the software aspect in order to run the program. 

## Career Exploration
### College Central
The college central site functions similar to the typical web job board. You can upload a resume, search for jobs, internships or volunteer positions and listen to different career podcasts. 
Using the Bearu of Labor statistics shows that for software developers, the job rate is growing faster than expected at 22%, the median pay is around $107k, and the typical entry level degree is a Bachelor's. 

### Certifications
There are three major IT certifications programs, CompTIA, Cisco and CISSP. CompTIA uses behavioral analytics to detect and combat cybersecurity threats. Cisco offers certification in a variety of topics and four levels of certification depending on your needs. Certification shows competence as a professional to install, configure, operate and troubleshoot routed and switched networks. CISSP certification demonstartes the ability to design, implement and manage cybersecurity systems. 

### Certificates 
One certificate program offered at TriC is the Post-Degree certificate in programming and development. This certificate demonstrates the ability to operate in a diverse environment, explain and implement technologies impacted by ethical and legal issues, plan, organize and prioritize to meet deadlines, and apply various programming knowledge. 

### Co-ops/Internships
To become co-op ready you must be a TriC student, complete 12 hous of course work with 2 courses being related to your major field and have a GPA of 2.75 or higher. The benefits of a co-op are the real world experience gained, the hands-on learning and being paid while still getting credit as if you took a course. 

### Industry Associations and Student Organizations
The purpose of the ACM-W is to support, celebrate and advocate for the full engagement of women in computing. They provide a wide range of programs and services to advance the technical contributions of women in computing. Membership would be beneficial because you gain acccess to the diferent types of research being conducted and create contacts with the researchers that are conducting it. You also will be inform about educational and jo opportunities avaiable to you. 

# Conclusion
The purpose of this lab was to gain insight into a few aspects of software, learn about virtualization, python, and different certificates, programs and opportunities avaialable to students and professionals in the field. One of the things that was difficult was the part rearding virtualization. It was a little difficult to follow but after reading the part about virtualization vs cloud computing it made more sense. The part that was particularly interesting was looking into the different certificates and their benefits. There are a lot of options to improve your skills and enhance your portfolio either pre or post degree. 
